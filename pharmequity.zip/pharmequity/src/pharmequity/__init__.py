"""pharmequity — systematic evaluation of allele-frequency disparities
across reference-population panels and their downstream effect on
pharmacogenomic dosing logic.
"""

__version__ = "0.1.0"
