# Data

## `synthetic_demo_frequencies.csv`

**This file is synthetic placeholder data, not real gnomAD data.**
It exists only so the pipeline is runnable out of the box and the
tests have something concrete to check against. The population
sizes (allele_number per population) are set to realistic gnomAD-
scale cohort sizes so the detection-floor and CI-width behavior looks
like a real run, but the allele counts/frequencies themselves are
made up. **Do not cite results generated from this file as findings.**

## Using real data

To run this on real allele frequencies:

1. Go to gnomAD (https://gnomad.broadinstitute.org), look up each
   variant of interest, and export/copy its per-population allele
   count/number/frequency table. gnomAD's own per-population export
   uses this same shape, so no reshaping should be needed beyond
   renaming columns to match `REQUIRED_COLUMNS` in `src/pharmequity/data.py`.
2. Alternatively, PharmGKB (https://www.pharmgkb.org) and CPIC publish
   population-frequency tables for CPIC-actionable variants directly —
   these are curated and citable.
3. Save your table as CSV with columns:
   `gene,variant_id,rsid,population,allele_count,allele_number,allele_frequency`
4. Run:
   ```
   pharmequity-cli --frequencies your_real_data.csv --out out/report
   ```

`load_frequency_table()` in `data.py` will reject the file if
`allele_frequency` doesn't match `allele_count/allele_number`, so a
bad export is caught immediately rather than silently analyzed.
